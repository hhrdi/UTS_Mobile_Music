package umn.ac.uts_25537_herdi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class halaman_login extends AppCompatActivity {
    private Button login;
    private EditText username;
    private EditText password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_login);
        this.setTitle("Login");

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.btnLogin);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(username.getText().toString(), password.getText().toString());

            }
        });

    }

    private void validate(String username, String password){
        if(username.equals("uasmobile")&&password.equals("uasmobilegenap"))
        {
            Intent intent= new Intent(this, list_lagu.class);
            startActivity(intent);
        }
        else
        {
            return;
        }
    }
}